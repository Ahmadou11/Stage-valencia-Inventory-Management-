### ECONOMIC PRODUCTION QUANTITY ###

# Import required libraries
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import messagebox


# Define EPQ function
def EPQ(D, P, S, H, days_per_year):
    
    """
    Economic Production Quantity
    
    Arguments:
    D: annual quantity demanded
    S: cost of production run
    H: holding cost per unit
    P: production rate
    
    Returns:
    [Q, cycle length, number_of_production_runs, production run length, demand period length, annual production cost, annual holding cost, maximum inventory level, annual total cost]
    
    """
    
    if(D>0 and P>0 and S>0 and H>0):
        
         # Calculate the number of working days in a year
        #days_per_year = 250
        # Calculate the daily demand rate
        d = D / days_per_year
        # Calculate Economic Production Quantity (EPQ) using the EPQ formula
        if d > P : 
            warning_message = "Warning: your daily demand is higher than production Rate, it is recommended to increase Production Rate (P)"
            messagebox.showwarning("Warning", warning_message)
        Q = (np.sqrt((2 * D * S) / (H * (1 - (d / P)))))
        # Calculate cycle length (time between two consecutive production runs)
        T = round(Q / D * 12, 2)
        # Calculate the number of production runs per year
        number_of_production_runs = D / max(Q, 0.0001)
        # Calculate the production run length (time to produce one EPQ batch)
        Tp = round(Q / P * 12, 2)
        # Calculate the demand period length (time to deplete one EPQ batch)
        Td = round((Q / D - Q / P) * 12, 2)
        # Calculate the annual production cost
        APC = number_of_production_runs * S #number_of_production_runs = D / Q
        # Calculate the annual holding cost
        AHC = (Q  * (1 - (d / P)) * H) / 2
        # Calculate the maximum inventory level
        Imax = Q * (1 - (d / P))
        # Calculate the annual total cost
        ATC = APC + AHC
        
        #return[Q , T, number_of_production_runs, Tp, Td, APC, AHC, Imax, ATC]
        # Convert the results to a formatted string
        result_str = f"Q: {round(Q)}\nCycle Length: {round(T)}\nNumber of Production Runs: {round(number_of_production_runs)}\nProduction Run Length: {round(Tp)}\nDemand Period Length: {round(Td)}\nAnnual Production Cost: {round(APC)}\nAnnual Holding Cost: {round(AHC)}\nMaximum Inventory Level: {round(Imax)}\nAnnual Total Cost: {round(ATC)}"
        return result_str
    
    else:
        print("Error. All function arguments must be non-negative.")
    
        
def calculate_epq_values():
    
    try:
        # Get the user input from the entry widgets
        D = float(D_entry.get())
        P = float(P_entry.get())
        S = float(S_entry.get())
        H = float(H_entry.get())
        days_per_year = float(days_per_year_entry.get())
        
        # Check if D is greater than 1999 and P is still 8 (a warning case)
        if D > 1999 and P == 8:
            warning_message = "Warning: For D > 1999, it is recommended to increase P.\nFor example: For 0 < D < 1999 --> P = 8\nFor D >= 1999 --> P should be increased."
            messagebox.showwarning("Warning", warning_message)
        
        # Call the EPQ function with the user-provided values
        result = EPQ(D, P, S, H, days_per_year)
    
        # Show the result in a messagebox
        messagebox.showinfo("EPQ Results", result)        

    
        # Create period list and append values
        period = [0]
        while period[-1] < 12:
            period.append(period[-1] + 1.2)
            period.append(period[-1] + 4.8)
            
        # Create inventory list and append values
        inventory = [0]
        while len(inventory) < len(period):
            inventory.append(80)
            inventory.append(0)
            

        # Plot inventory level graph
        plt.figure(figsize=(15,5))
        plt.plot(period,inventory)
        plt.plot([0,1.2],[0,100], linestyle="dashed", label="Production Rate")
        plt.xlabel("Month")
        plt.ylabel("Inventory Level")
        plt.title("Economic Production Quantity")
        plt.legend()
        plt.show()
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numeric values ")

# Create a simple Tkinter GUI
root = tk.Tk()
root.title("POQ Calculator")

# Create entry widgets for user input

D_label = tk.Label(root, text="Annual Quantity Demanded (D):")
D_label.grid(row=0, column=0)
D_entry = tk.Entry(root)
D_entry.grid(row=0, column=1)
D_entry.insert(tk.END, "1000")
D_label = tk.Label(root, text="quantity/years")
D_label.grid(row=0, column=2)


P_label = tk.Label(root, text="Production Rate (P):")
P_label.grid(row=1, column=0)
P_entry = tk.Entry(root)
P_entry.grid(row=1, column=1)
P_entry.insert(tk.END, "8")
P_label = tk.Label(root, text="units/day")
P_label.grid(row=1, column=2)

S_label = tk.Label(root, text="Cost of Production Run (S):")
S_label.grid(row=2, column=0)
S_entry = tk.Entry(root)
S_entry.grid(row=2, column=1)
S_entry.insert(tk.END, "10")
S_label = tk.Label(root, text="euros")
S_label.grid(row=2, column=2)

H_label = tk.Label(root, text="Holding Cost per Unit (H):")
H_label.grid(row=3, column=0)
H_entry = tk.Entry(root)
H_entry.grid(row=3, column=1)
H_entry.insert(tk.END, "0.50")
H_label = tk.Label(root, text="euros")
H_label.grid(row=3, column=2)

days_per_year_label = tk.Label(root, text="Working Days")
days_per_year_label.grid(row=4, column=0)
days_per_year_entry = tk.Entry(root)
days_per_year_entry.grid(row=4, column=1)
days_per_year_entry.insert(tk.END, "250")
days_per_year_label = tk.Label(root, text="years")
days_per_year_label.grid(row=4, column=2)


# Create a button to trigger the calculation
calculate_button = tk.Button(root, text="Calculate EPQ", command=calculate_epq_values)
calculate_button.grid(row=5, column=0, columnspan=2)

#title_label = tk.Label(root, text="If you want to increase D you need to increase P \n \t For example : For 0<D<1999 --> P=8, for 1999<D<... --> 9<P<...", font=("Helvetica", 10))
#title_label.grid(row=5, column=0)

#root.geometry("500x300+50+50")

root.mainloop()