import tkinter as tk
from tkinter import messagebox
import subprocess

def run_simulation():
    try:
        selected_option = variable.get()
        if selected_option == 1:
            subprocess.run(['python', 'stochastic_demand_s_Q.py', '-s', 'Q'])
        elif selected_option == 2:
            subprocess.run(['python', 'stochastic_demand_s_S.py', '-s', 'S'])
        elif selected_option == 3:
            subprocess.run(['python', 'stochastic_demand_R_S.py', '-R', 'S'])
        elif selected_option == 4:
            subprocess.run(['python', 'stochastic_demand_R_s_S.py', '-R', 's', 'S'])
        else:
            messagebox.showerror("Error", "Please select a valid option.")
    except FileNotFoundError:
        messagebox.showerror("Error", "Simulation file not found.")

# Créer une fenêtre tkinter
window = tk.Tk()
window.title("Simulation Options")

# Ajouter un titre à la fenêtre
title_label = tk.Label(window, text="Simulation of an inventory with stochastic demand \n Choose the policy you want to simulate", font=("Helvetica", 24))
title_label.pack(pady=20)

# Créer un cadre pour les options de sélection
frame = tk.Frame(window)
frame.pack()

# Créer une variable pour la sélection de l'option
variable = tk.IntVar()

# Créer des boutons radio pour les options
option1 = tk.Radiobutton(frame, text="Policy - (s, Q)", variable=variable, value=1)
option1.pack(anchor=tk.W)

option2 = tk.Radiobutton(frame, text="Policy - (s, S)", variable=variable, value=2)
option2.pack(anchor=tk.W)

option3 = tk.Radiobutton(frame, text="Policy - (R, S)", variable=variable, value=3)
option3.pack(anchor=tk.W)

option4 = tk.Radiobutton(frame, text="Policy - (R, s, S)", variable=variable, value=4)
option4.pack(anchor=tk.W)

# Créer un bouton pour lancer la simulation
button_simulate = tk.Button(window, text="Run", command=run_simulation)
button_simulate.pack()

# Ajouter un emplacement pour une image
image = tk.PhotoImage(file="inven1.png")  # Remplacez "image.png" par le chemin de votre image
image_label = tk.Label(window, image=image)
image_label.pack(pady=20)

# Exécuter la boucle d'événements tkinter
window.mainloop()
