import numpy as np
import simpy
import itertools
import matplotlib.pyplot as plt
import pandas as pd
import tkinter as tk
from tkinter import messagebox

# Simulation constants
MEAN_IAT = 0.1                       # average time between customer demands (months)
START_INVENTORY = 60.               # units in inventory at simulation start
COST_ORDER_SETUP = 32.              # fixed cost of placing an order
COST_ORDER_PER_ITEM = 3.            # variable cost of ordering an item
COST_BACKLOG_PER_ITEM = 5.          # monthly cost for each item in backlog
COST_HOLDING_PER_ITEM = 1.          # monthly cost for each item in inventory
# SIM_LENGTH = 120.                   # duration of the simulation (in months)

class InventorySystem:
    """ Single product inventory system using a fixed reorder point
    and order-up-to-level (s, S) policy. Inventory is reviewed at periodic intervals """
    
    def __init__(self, env:simpy.Environment, review_period, reorder_point, reorder_level, demand_mean, demand_std):
        # initialize values
        self.reorder_point = reorder_point
        self.reorder_level = reorder_level
        self.demand_mean = demand_mean
        self.demand_std = demand_std
        self.level = START_INVENTORY
        self.last_change = 0.
        self.ordering_cost = 0.
        self.shortage_cost = 0.
        self.holding_cost = 0.
        self.history = [(0., START_INVENTORY)]
        self.ioh_history = []
        self.num_orders = 0
        self.orders_placed = []  # initialize orders_placed list
        self.orders_received = []
        self.net_stock_history = []  #  liste net_stock_history
        self.demand_fulfilled = 0  # Nombre de demandes satisfaites initialement à zéro
        self.stock_in_transit = 0 
        self.env = env
        self.review_period = review_period
        self.time_since_review = 0
        # launch processes
        env.process(self.check_inventory(env))
        env.process(self.demands(env))

    def place_order(self, env, units):
        """ Place and receive orders """
        # update ordering costs
        self.ordering_cost += (COST_ORDER_SETUP
                               + units * COST_ORDER_PER_ITEM)
        # determine when order will be received
        #lead_time = np.random.uniform(.5, 1.0)
        lead_time = 0
        yield env.timeout(lead_time)
        # update inventory level and costs
        self.update_cost(env)
        self.level += units
        self.stock_in_transit -= units
        self.last_change = env.now
        self.history.append((env.now, self.level))
        self.update_cost(env)
        self.num_orders += 1
        self.orders_placed.append((env.now, units))

    def check_inventory(self, env):
        """ Check inventory level at regular intervals and place
        orders to reach reorder level """
        while True:
            yield env.timeout(self.review_period)
            self.time_since_review += self.review_period
            if self.time_since_review >= self.review_period and self.level <= self.reorder_point:
                self.time_since_review = 0
                units = self.reorder_level - self.level
                env.process(self.place_order(env, units))
            # wait for next check
            yield env.timeout(1.0)

    def receive_order(self, env, units):
        """ Receive orders and update transit orders """
        # update transit orders
        self.orders_received.append((env.now, units))
        self.stock_in_transit += units  # Incrémenter le stock en transit
        self.orders_placed = [(t, u) for (t, u) in self.orders_placed if t > env.now]

    def calculate_stock_in_transit(self):
        return self.stock_in_transit
    
    def update_cost(self, env):
        """ Update holding and shortage cost at each inventory
         movement """
        """ Mise à jour des coûts de possession et de rupture à chaque mouvement des stocks"""
        # update shortage cost
        if self.level <= 0:
            shortage_cost = (abs(self.level)
                             * COST_BACKLOG_PER_ITEM
                             * (env.now - self.last_change))
            self.shortage_cost += shortage_cost
        else:
            # update holding cost
            holding_cost = (self.level
                            * COST_HOLDING_PER_ITEM
                            * (env.now - self.last_change))
            self.holding_cost += holding_cost

        # calculate stock position
        #stock_position = self.level + self.order_size - self.get_demand()
        # print stock position
        print(f"Stock position at time {env.now}: {self.level}")

    def get_demand(self):
        """ Get the demand at the current time """
        return max(0, int(np.random.normal(loc=self.demand_mean, scale=self.demand_std)))

    def demands(self, env):
        """ Generate demand at random intervals and update
         inventory level """
        counter = 0  # demand counter
        while True:
            # Generate next demand size and time
            iat = np.random.exponential(MEAN_IAT)
            size = self.get_demand()
            counter += 1  # increment counter for next demand
            # wait for a period
            yield env.timeout(iat)
            # Update inventory level and costs upon demand receipt
            self.update_cost(env)
            self.level -= size
            self.last_change = env.now
            self.history.append((env.now, self.level))
            if size <=self.level:
                self.demand_fulfilled += 1  # Incrémenter le nombre de demandes satisfaites
            # Calculate and store the net stock at this point
            net_stock = max(0, self.level)  # Stock net ne peut pas être négatif
            self.net_stock_history.append(net_stock)
            print(f"Net stock : {net_stock}")

    def calculate_ioh(self):
        ioh = []
        for i in range(len(self.history)):
            stock_position = max(0, self.history[i][1])
            ioh.append(stock_position)
        self.ioh_history = ioh
        
    def calculate_fill_rate(self):
        """ Calculate the Fill Rate """
        total_demands = len(self.history)  # Nombre total de demandes
        fill_rate = (self.demand_fulfilled / total_demands) * 100  # Calcul du Fill Rate en pourcentage
        return fill_rate

def run(review_period : float , reorder_point: float, reorder_level: float, sim_length: float, demand_mean: float, demand_std: float,
        display_chart=False):
    """ Runs inventory system simulation for a given length and returns
    simulation results in a dictionary

    Args:
        - reorder_point: inventory level which triggers reorder
        - reorder_level: inventory level to be replenished to
        - sim_length: duration of the simulation, in months
    """
    # check user inputs
    if sim_length <= 0:
        raise ValueError("Simulation length must be greater than zero")

    # setup simulation
    env = simpy.Environment()
    inv = InventorySystem(env, review_period, reorder_point, reorder_level, demand_mean, demand_std)
    env.run(sim_length)

    # calculate IOH
    inv.calculate_ioh()

    # compute and return simulation results
    avg_total_cost = (inv.ordering_cost
                      + inv.holding_cost
                      + inv.shortage_cost) / sim_length
    avg_ordering_cost = inv.ordering_cost / sim_length
    avg_holding_cost = inv.holding_cost / sim_length
    avg_shortage_cost = inv.shortage_cost / sim_length
    num_orders = inv.num_orders
    results = {'reorder_point': reorder_point,
               'reorder_level': reorder_level,
               'total_cost': round(avg_total_cost, 1),
               'ordering_cost': round(avg_ordering_cost, 1),
               'holding_cost': round(avg_holding_cost, 1),
               'shortage_cost': round(avg_shortage_cost, 1),
               'num_orders': num_orders}

    # calculate average, maximum, and minimum inventory
    inventory_levels = [x[1] for x in inv.history]
    avg_inventory = np.mean(inventory_levels)
    max_inventory = np.max(inventory_levels)
    min_inventory = np.min(inventory_levels)
    results['avg_inventory'] = round(avg_inventory, 1)
    results['max_inventory'] = max_inventory
    results['min_inventory'] = min_inventory

    if display_chart == True:
        step_graph(inv)

    return inv, results


def step_graph(inventory):
    """ Displays a step line chart of inventory level """
    # create subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    # plot inventory level
    x_val = [x[0] for x in inventory.history]
    y_val = [x[1] for x in inventory.history]
    ax1.step(x_val, y_val, where='post', label='Units in inventory')
    ax1.axhline(y=inventory.reorder_level, color='green', linestyle='-', label='Reorder level')
    ax1.axhline(y=inventory.reorder_point, color='red', linestyle='-', label='Reorder point')
    ax1.set_xlabel('Months')
    ax1.set_ylabel('Stock net')
    ax1.set_title(f'Simulation output for system (R = {inventory.review_period} ,s = {inventory.reorder_point}, S ={inventory.reorder_level})')
    ax1.legend()

    # plot IOH
    x_val_ioh = x_val
    y_val_ioh = inventory.ioh_history
    ax1.plot(x_val_ioh, y_val_ioh, label='Stock On Hand')
    ax1.legend()
    
    """
    # Plot stock in transit
    time_values = [x[0] for x in inventory.orders_placed]
    stock_in_transit = [x[1] for x in inventory.orders_placed]
    ax3.plot(time_values, stock_in_transit, marker='o', color='purple', label='Stock in Transit')
    ax3.set_xlabel('Time (months)')
    ax3.set_ylabel('Stock in Transit')
    ax3.set_title('Stock in Transit over Time')
    ax3.legend()
    ax3.set_ylim(0, 100)
    """
    """
    # Calculate and plot net stock
    net_stock = [max(0, level) for level in y_val]
    ax3.plot(x_val, net_stock, label='Net Stock', color='purple')
    ax3.legend()
    """
    # plot demand
    demand_val = [max(0, int(np.random.normal(loc=inventory.demand_mean, scale=inventory.demand_std))) for _ in
                  inventory.history]
    ax2.step(x_val, demand_val, marker='o', color='blue', label='Demand')
    ax2.set_xlabel('Months')
    ax2.set_ylabel('Demand')
    ax2.set_title('Demand evolution')
    ax2.legend()
    ax2.set_ylim(0, 5)

    manager = plt.get_current_fig_manager()
    manager.window.title('Stochastic graph modèle (s,S)')

    # adjust layout and display the figure
    plt.tight_layout()
    plt.show()


def run_simulation():
    """ Callback function for running the simulation """
    try:
        reorder_point = float(reorder_entry.get())
        reorder_level = float(reorder_level_entry.get())
        sim_length = float(length_entry.get())
        review_period = float(review_period_entry.get())
        demand_mean = float(demand_mean_entry.get())  # Read demand mean from entry field
        demand_std = float(demand_std_entry.get())

        inv, result = run(review_period, reorder_point, reorder_level, sim_length, demand_mean, demand_std, display_chart=True)
        fill_rate = inv.calculate_fill_rate()
        result_text = f"Total Cost: {result['total_cost']} euros\n" \
                      f"Ordering Cost: {result['ordering_cost']} euros\n" \
                      f"Holding Cost: {result['holding_cost']} euros\n" \
                      f"Shortage Cost: {result['shortage_cost']} euros\n" \
                      f"Avg Inventory: {result['avg_inventory']} units\n" \
                      f"Max Inventory: {result['max_inventory']} units\n" \
                      f"Min Inventory: {result['min_inventory']} units\n" \
                      f"Number of Orders: {result['num_orders']} orders\n" \
                      f"Fill Rate: {fill_rate:.2f}% " 

        result_label.config(text=result_text)

    except ValueError as e:
        result_label.config(text=str(e))


# Create GUI
root = tk.Tk()
root.title("Stochastic simulation")

# Reorder Point Label
reorder_label = tk.Label(root, text="Reorder Point:")
reorder_label.grid(row=0, column=0)

# Reorder Point Entry
reorder_entry = tk.Entry(root)
reorder_entry.grid(row=0, column=1)
reorder_entry.insert(tk.END, "20")
reorder_label = tk.Label(root, text=" units")
reorder_label.grid(row=0, column=2)

# Reorder Level Label
reorder_level_label = tk.Label(root, text="Reorder Level:")
reorder_level_label.grid(row=1, column=0)

# Reorder Level Entry
reorder_level_entry = tk.Entry(root)
reorder_level_entry.grid(row=1, column=1)
reorder_level_entry.insert(tk.END, "50")
reorder_level_label = tk.Label(root, text=" units")
reorder_level_label.grid(row=1, column=2)

# Simulation Length Label
length_label = tk.Label(root, text="Simulation Length:")
length_label.grid(row=2, column=0)

# Simulation Length Entry
length_entry = tk.Entry(root)
length_entry.grid(row=2, column=1)
length_entry.insert(tk.END, "10")
length_label = tk.Label(root, text="months")
length_label.grid(row=2, column=2)

# Demand Mean Label
demand_mean_label = tk.Label(root, text="Average:")
demand_mean_label.grid(row=3, column=0)

# Demand Mean Entry
demand_mean_entry = tk.Entry(root)
demand_mean_entry.grid(row=3, column=1)
demand_mean_entry.insert(tk.END, "3")
demand_mean_label = tk.Label(root, text=" units")
demand_mean_label.grid(row=3, column=2)

# Demand Standard Deviation Label
demand_std_label = tk.Label(root, text="Standard Deviation:")
demand_std_label.grid(row=4, column=0)

# Demand Standard Deviation Entry
demand_std_entry = tk.Entry(root)
demand_std_entry.grid(row=4, column=1)
demand_std_entry.insert(tk.END, "0.5")
demand_std_label = tk.Label(root, text=" units")
demand_std_label.grid(row=4, column=2)

# Review Period Label
review_period_label = tk.Label(root, text="Review Period:")
review_period_label.grid(row=5, column=0)  # Adjust row number

# Review Period Entry
review_period_entry = tk.Entry(root)
review_period_entry.grid(row=5, column=1)  # Adjust row number
review_period_entry.insert(tk.END, "2")  # Default review period
review_period_label = tk.Label(root, text="months")
review_period_label.grid(row=5, column=2)  # Adjust row number

# Run Simulation Button
run_button = tk.Button(root, text="Run Simulation", command=run_simulation)
run_button.grid(row=6, column=0, columnspan=2)

# Result Label
result_label = tk.Label(root, text="")
result_label.grid(row=7, column=0, columnspan=2)

root.geometry("500x300+50+50")

root.mainloop()
