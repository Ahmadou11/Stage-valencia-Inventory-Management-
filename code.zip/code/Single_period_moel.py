import numpy as np
import tkinter as tk
from tkinter import ttk

def single_period_model(demand_mean, demand_std, sales_price, cost_per_unit, salvage_value):
    demand = max(0, int(np.random.normal(loc=demand_mean, scale=demand_std)))
    cost_of_shortage = sales_price - cost_per_unit
    cost_of_overage = cost_per_unit - salvage_value
    service_level = cost_of_shortage / (cost_of_shortage + cost_of_overage)
    return demand, service_level

def run_single_period_simulation(demand_mean, demand_std, sales_price, cost_per_unit, salvage_value, iterations=10000):
    total_service_level = 0
    optimal_stock_level = 0
    stockout_risk = 0
    for _ in range(iterations):
        demand, service_level = single_period_model(demand_mean, demand_std, sales_price, cost_per_unit, salvage_value)
        total_service_level += service_level
        optimal_stock_level += demand + (0.20 * demand_std)
        stockout_risk += 1 - service_level
    average_service_level = total_service_level / iterations
    average_optimal_stock_level = optimal_stock_level / iterations
    average_stockout_risk = stockout_risk / iterations
    return average_service_level, average_optimal_stock_level, average_stockout_risk

def calculate_service_level():
    demand_mean = float(demand_mean_entry.get())
    demand_std = float(demand_std_entry.get())
    sales_price = float(sales_price_entry.get())
    cost_per_unit = float(cost_per_unit_entry.get())
    salvage_value = float(salvage_value_entry.get())
    iterations = int(iterations_entry.get())

    average_service_level, average_optimal_stock_level, average_stockout_risk = run_single_period_simulation(demand_mean, demand_std, sales_price, cost_per_unit, salvage_value, iterations)
    
    result_label.config(text=f"Average Service Level: {average_service_level:.3f}\n"
                             f"Average Optimal Stock Level: {average_optimal_stock_level:.3f}\n"
                             f"Average Stockout Risk: {average_stockout_risk:.3f}\n"
                             f"Average Stockout Risk: {average_stockout_risk * 100:.3f}%")

# Create GUI
root = tk.Tk()
root.title("Single-Period Model Simulation")

""" 
# Reorder Point Label
reorder_label = tk.Label(root, text="Reorder Point:")
reorder_label.grid(row=0, column=0)

# Reorder Point Entry
reorder_entry = tk.Entry(root)
reorder_entry.grid(row=0, column=1)
reorder_entry.insert(tk.END, "20")
reorder_label = tk.Label(root, text=" units")
reorder_label.grid(row=0, column=2)
"""
# Demand Mean Label and Entry
demand_mean_label = tk.Label(root, text="Average Demand:")
demand_mean_label.grid(row=0, column=0)
demand_mean_entry = tk.Entry(root)
demand_mean_entry.grid(row=0, column=1)
demand_mean_entry.insert(tk.END, "120")
demand_mean_label = tk.Label(root, text=" quantity/day")
demand_mean_label.grid(row=0, column=2)  

# Demand Standard Deviation Label and Entry
demand_std_label = tk.Label(root, text="Demand Standard Deviation:")
demand_std_label.grid(row=1, column=0)
demand_std_entry = tk.Entry(root)
demand_std_entry.grid(row=1, column=1)
demand_std_entry.insert(tk.END, "15")
demand_std_label = tk.Label(root, text=" quantity")
demand_std_label.grid(row=1, column=2)

# Sales Price Label and Entry
sales_price_label = tk.Label(root, text="Sales price per unit : ")
sales_price_label.grid(row=2, column=0)
sales_price_entry = tk.Entry(root)
sales_price_entry.grid(row=2, column=1)
sales_price_entry.insert(tk.END, "1.25")
sales_price_label = tk.Label(root, text=" euros")
sales_price_label.grid(row=2, column=2)

# Cost per Unit Label and Entry
cost_per_unit_label = tk.Label(root, text="Cost per unit:")
cost_per_unit_label.grid(row=3, column=0)
cost_per_unit_entry = tk.Entry(root)
cost_per_unit_entry.grid(row=3, column=1)
cost_per_unit_entry.insert(tk.END, "0.70")
cost_per_unit_label = tk.Label(root, text=" euros")
cost_per_unit_label.grid(row=3, column=2)

# Salvage Value Label and Entry
salvage_value_label = tk.Label(root, text="Salvage Value per Unit:")
salvage_value_label.grid(row=4, column=0)
salvage_value_entry = tk.Entry(root)
salvage_value_entry.grid(row=4, column=1)
salvage_value_entry.insert(tk.END, "0.30")
salvage_value_label = tk.Label(root, text=" euros")
salvage_value_label.grid(row=4, column=2)

# Iterations Label and Entry
iterations_label = tk.Label(root, text="Number of Iterations:")
iterations_label.grid(row=5, column=0)
iterations_entry = tk.Entry(root)
iterations_entry.grid(row=5, column=1)
iterations_entry.insert(tk.END, "100")
iterations_label = tk.Label(root, text=" ")
iterations_label.grid(row=5, column=2)

# Calculate Button
calculate_button = ttk.Button(root, text="Calculate Average Service Level", command=calculate_service_level)
calculate_button.grid(row=6, column=0, columnspan=2)

# Result Label
result_label = tk.Label(root, text="")
result_label.grid(row=7, column=0, columnspan=2)


root.mainloop()
