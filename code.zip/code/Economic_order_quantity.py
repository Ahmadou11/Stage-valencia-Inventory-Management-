import tkinter as tk
from tkinter import messagebox
import numpy as np
import matplotlib.pyplot as plt


def EOQ(S, D, H):
    """
    Economic Order Quantity
    
    Arguments:
    S: ordering cost
    D: annual quantity demanded
    H: holding cost per unit
    
    Returns:
    [Q, number_of_orders, time_between_cycles, annual ordering cost, annual holding cost, annual total cost]
    """
    
    if S > 0 and D > 0 and H > 0:
        Q = (np.sqrt(2*S*D/H))  # Calculate the economic order quantity
        number_of_orders = D/Q  # Calculate the number of orders per year
        time_between_cycles = 12/number_of_orders  # Calculate the time between order cycles
        AOC = D*S/Q  # Calculate the annual ordering cost
        AHC = Q*H/2 # Calculate the annual holding cost
        ATC = AOC+AHC  # Calculate the annual total cost

        return [Q, number_of_orders, time_between_cycles, AOC, AHC, ATC]
    else:
        print("Error. All function arguments must be non-negative.")

def calculate_rop(D, lead_time):
    """
    Calculate Reorder Point (ROP)

    Arguments:
    D: annual quantity demanded
    lead_time: lead time (in days) for order

    Returns:
    The calculated Reorder Point (ROP)
    """
    days_per_year = 250  
    demand_per_day = D / days_per_year
    rop = demand_per_day * lead_time
    return rop

def calculate_eoq():
    # Get input values from entry fields
    try:
        S = float(entry_s.get())
        D = float(entry_d.get())
        H = float(entry_h.get())
        lead_time = float(entry_lead_time.get())

        # Calculate EOQ
        result = EOQ(S, D, H)
        # Calculate and display ROP
        rop = calculate_rop(D, lead_time)

        # Display results in a message box
        message = f"EOQ: {round(result[0])}\nNumber of Orders: {round(result[1])}\nTime Between Cycles:{round(result[2])}\n" \
                  f"Annual Ordering Cost: {round(result[3])}\nAnnual Holding Cost: {round(result[4])}\nAnnual Total Cost: {round(result[5])}\n"\
                  f"ROP (Reorder Point): {rop}"
        messagebox.showinfo("EOQ Results", message)

        # Create period list and append values
        period = [0, 2]
        while period[-1] < 12:
            period.append(period[-1])
            period.append(period[-1] + 2)

        # Create inventory list and append values
        inventory = [result[0], 0]
        while len(inventory) < len(period):
            inventory.append(result[0])
            inventory.append(0)

        # Plot inventory level graph
        plt.figure(figsize=(15, 5))
        plt.plot(period, inventory)
        plt.xlabel("Month")
        plt.ylabel("Inventory Level")
        plt.title("Economic Order Quantity")
        manager = plt.get_current_fig_manager()
        manager.window.title('EOQ graph')
        plt.show()
        
        # Calculate total cost for different order quantities
        order_quantities = np.arange(0, result[0] * 2, result[0] / 10)
        total_costs = []
        holding_costs = []
        ordering_costs = []
        for quantity in order_quantities:
            eoq_result = EOQ(S, D, H)
            eoq_result[0] = quantity  # Set the order quantity to the current value
            holding_cost = eoq_result[0] * H / 2
            if eoq_result[0] != 0:
                    ordering_cost = D * S / eoq_result[0]
            else:
                    ordering_cost = float('inf')
            total_cost = holding_cost + ordering_cost
            total_costs.append(total_cost)
            holding_costs.append(holding_cost)
            ordering_costs.append(ordering_cost)

        # Find intersection point
        intersection_index = np.argmin(np.abs(np.array(holding_costs) - np.array(ordering_costs)))

        # Plot total cost, holding cost, and ordering cost vs. order quantity
        plt.figure(figsize=(10, 6))
        plt.plot(order_quantities, total_costs, label='Total Cost (TC)')
        plt.plot(order_quantities, holding_costs, label='Holding Cost (QH/2)')
        plt.plot(order_quantities, ordering_costs, label='Ordering Cost (DS/Q)')
        plt.axvline(x=order_quantities[intersection_index], color='r', linestyle='--', label='Intersection')
        plt.xlabel("Order Quantity")
        plt.ylabel("Annual Cost")
        plt.title("Annual Cost vs Order Quantity ")
        plt.legend()
        plt.grid(True)
        manager = plt.get_current_fig_manager()
        manager.window.title('Annual Cost vs Order Quantity graph')
        plt.show()
        
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numeric values for S, D, and H.")


# Create tkinter window
window = tk.Tk()
window.title("EOQ Calculator")

# Create input labels and entry fields
label_s = tk.Label(window, text="Ordering Cost (S):")
label_s.grid(row=0, column=0)
entry_s = tk.Entry(window)
entry_s.grid(row=0, column=1)
entry_s.insert(tk.END, "10")
label_s = tk.Label(window, text="euros")
label_s.grid(row=0, column=2)


label_d = tk.Label(window, text="Annual Quantity Demanded (D):")
label_d.grid(row=1, column=0)
entry_d = tk.Entry(window)
entry_d.grid(row=1, column=1)
entry_d.insert(tk.END, "1000")
label_d = tk.Label(window, text="quantity/years")
label_d.grid(row=1, column=2)

label_h = tk.Label(window, text="Holding Cost per Unit (H):")
label_h.grid(row=2, column=0)
entry_h = tk.Entry(window)
entry_h.grid(row=2, column=1)
entry_h.insert(tk.END, "0.5")
label_h = tk.Label(window, text="euros")
label_h.grid(row=2, column=2)

label_lead_time = tk.Label(window, text="Lead Time (days):")
label_lead_time.grid(row=3, column=0)
entry_lead_time = tk.Entry(window)
entry_lead_time.grid(row=3, column=1)
entry_lead_time.insert(tk.END, "7")  

# Create calculate button
button_calculate = tk.Button(window, text="Calculate EOQ", command=calculate_eoq)
button_calculate.grid(row=4, column=0, columnspan=2)

# Run the tkinter event loop
window.mainloop()
