import tkinter as tk
from tkinter import messagebox
import numpy as np
import matplotlib.pyplot as plt


def EOQ(S, D, H, I, P):
    """
    Economic Order Quantity
    
    Arguments:
    S: ordering cost
    D: annual quantity demanded
    H: holding cost per unit
    I: holding cost as a percentage of unit price
    P: unit price
    
    Returns:
    [Q, number_of_orders, time_between_cycles, annual ordering cost, annual holding cost, annual total cost]
    """
    
    if S > 0 and D > 0 and H > 0 and I >= 0 and P > 0:
        Q = (np.sqrt(2*S*D/(I*P)))  # Calculate the economic order quantity for discount)
        number_of_orders = D/Q  # Calculate the number of orders per year
        time_between_cycles = 12/number_of_orders  # Calculate the time between order cycles
        AOC = D*S/Q  # Calculate the annual ordering cost
        AHC = Q*H/2  # Calculate the annual holding cost
        ATC = AOC + AHC + P*D # Calculate the annual total cost

        return [Q, number_of_orders, time_between_cycles, AOC, AHC, ATC]
    else:
        print("Error. All function arguments must be non-negative.")
    
def calculate_rop(D, lead_time):
    """
    Calculate Reorder Point (ROP)

    Arguments:
    D: annual quantity demanded
    lead_time: lead time (in days) for order

    Returns:
    The calculated Reorder Point (ROP)
    """
    days_per_year = 250  
    demand_per_day = D / days_per_year
    rop = demand_per_day * lead_time
    return rop

def calculate_eoq():
    try:
        S = float(entry_s.get())
        D = float(entry_d.get())
        H = float(entry_h.get())
        I = float(entry_i.get())   # Convert percentage to decimal
        P = float(entry_p.get())
        lead_time = float(entry_lead_time.get())
        
        # Get tiered prices and corresponding quantities
        tiered_prices = [float(entry_price_tier_1.get()), float(entry_price_tier_2.get()), float(entry_price_tier_3.get())]
        tiered_quantities = [float(entry_quantity_range_1.get()), float(entry_quantity_range_2.get()), float(entry_quantity_range_3.get())]

        # Check the validity of quantity ranges
        if not (1 <= tiered_quantities[0] <= 1000 and 1000 < tiered_quantities[1] <= 2000 and tiered_quantities[2] > 2000):
            messagebox.showerror("Error", "Invalid quantity ranges. Please make sure the quantity ranges are correct.")
            return
        
        best_price = 0
        best_quantity = 0
        lowest_total_cost = float('inf')

        for price, quantity in zip(tiered_prices, tiered_quantities):
            Q_ = (np.sqrt(2*S*D/(I*price)))
            AOC_ = D*S/quantity 
            AHC_ = quantity*I*price/2  
            total_cost = AOC_ + AHC_ + price*D 
            
            if total_cost < lowest_total_cost:
                lowest_total_cost = total_cost
                best_price = price
                best_quantity = quantity
            
            # Afficher le calcul pour chaque quantité
            print(f"Calcul for Quantity {quantity}:")
            print(f"EOQ : {round(Q_)}")
            print(f"Annual Ordering Cost: {round(AOC_)}")
            print(f"Annual Holding Cost: {round(AHC_)}")
            print(f"Annual Total Cost: {round(total_cost)}")
            print("\n")
        
        result = EOQ(S, D, H, I, P)
        # Calculate and display ROP
        rop = calculate_rop(D, lead_time)
    
        # Display results in a message box
        message = f"EOQ: {round(result[0])}\nNumber of Orders: {round(result[1])}\nTime Between Cycles:{round(result[2])}\n" \
                  f"Annual Ordering Cost: {round(result[3])}\nAnnual Holding Cost: {round(result[4])}\nAnnual Total Cost: {round(result[5])}\n"\
                  f"ROP (Reorder Point): {rop}\n"\
                  f"Best Price: {best_price}\nBest Quantity to Order: {best_quantity}"

        # Display results in a message box
        messagebox.showinfo("Quantity discount Results", message)

        
        # Calculate total cost for different order quantities
        tiered_quantities = [float(entry_quantity_range_1.get()), float(entry_quantity_range_2.get()), float(entry_quantity_range_3.get())]
        total_costs = []
        holding_costs = []
        ordering_costs = []
        
        for price, quantity in zip(tiered_prices, tiered_quantities):
            
            holding_cost = quantity * I * price / 2
            
            if result[0] != 0:
                    ordering_cost = D * S / quantity
            else:
                    ordering_cost = float('inf')
            
            total_cost = holding_cost + ordering_cost + D * price
            
            total_costs.append(total_cost)
            holding_costs.append(holding_cost)
            ordering_costs.append(ordering_cost)

        ############################## Plot ############################################
        # Calculate total cost for different order quantities within the range 1-1000
        min_1 = (np.sqrt(2*S*D/(I*tiered_prices[0]))) 
        quantity_range_1 = np.arange(min_1/10, 1000)  # Range 1-1000
        total_costs_range_1 = []
        price_1 = tiered_prices[0]
        
        for quantity in quantity_range_1:
            AOC_ = D * S / quantity
            AHC_ = quantity * I * price_1 / 2
            total_cost = AOC_ + AHC_ + price_1 * D
            total_costs_range_1.append(total_cost)
            
        # Calculate total cost for different order quantities within the range 1000-2000
        min_2 = (np.sqrt(2*S*D/(I*tiered_prices[1]))) 
        quantity_range_2 = np.arange(min_2/5, 2000)  # Range 1000-2000
        total_costs_range_2 = []
        price_2 = tiered_prices[1]

        for quantity in quantity_range_2:
            
            AOC_ = D * S / quantity
            AHC_ = quantity * I * price_2 / 2
            total_cost = AOC_ + AHC_ + price_2 * D
            total_costs_range_2.append(total_cost)

        # Calculate total cost for different order quantities within the range above 2000
        min_3 = (np.sqrt(2*S*D/(I*tiered_prices[2]))) 
        quantity_range_3 = np.arange(min_3/2, 3000)  # Range above 2000
        total_costs_range_3 = []
        price_3 = tiered_prices[2]

        for quantity in quantity_range_3:
            AOC_ = D * S / quantity
            AHC_ = quantity * I * price_3 / 2
            total_cost = AOC_ + AHC_ + price_3 * D
            total_costs_range_3.append(total_cost)
            
        # Plot total cost curves for the different quantity ranges
        plt.figure(figsize=(10, 6))
        plt.plot(quantity_range_1, total_costs_range_1, label='Total Cost (Quantity Range 1-1000)')
        plt.plot(quantity_range_2, total_costs_range_2, label='Total Cost (Quantity Range 1000-2000)')
        plt.plot(quantity_range_3, total_costs_range_3, label='Total Cost (Quantity Range 2000-3000)')
        
        # Highlight the part before 1000 units of order quantity with a dashed line
        plt.plot(quantity_range_2[:850], total_costs_range_2[:850], linestyle='dashed', color='red')
        # Highlight the part before 1000 units of order quantity with a dashed line
        plt.plot(quantity_range_3[:1600], total_costs_range_3[:1600], linestyle='dashed', color='red')
        
        # Add a point for the calculation (np.sqrt(2*S*D/(I*tiered_prices[1])))
        Q_1 = np.sqrt(2*S*D/(I*tiered_prices[0]))
        calculation_point_y = D * S / Q_1 + (Q_1 * I * tiered_prices[0] / 2) + tiered_prices[0] * D
        plt.scatter(Q_1, calculation_point_y, color='red', label='Q_price_1')
        # Add a point for the calculation (np.sqrt(2*S*D/(I*tiered_prices[1])))
        Q_2 = np.sqrt(2*S*D/(I*tiered_prices[1]))
        calculation_point_y = D * S / Q_2 + (Q_2 * I * tiered_prices[1] / 2) + tiered_prices[1] * D
        plt.scatter(Q_2, calculation_point_y, color='red', label='Q_price_2')
        # Add a point for the calculation (np.sqrt(2*S*D/(I*tiered_prices[1])))
        Q_3 = np.sqrt(2*S*D/(I*tiered_prices[2]))
        calculation_point_y = D * S / Q_3 + (Q_3 * I * tiered_prices[2] / 2) + tiered_prices[2] * D
        plt.scatter(Q_3, calculation_point_y, color='red', label='Q_price_3')
        
        
        plt.axvline(x=max(quantity_range_1), color='b', linestyle='--', label=f'Max Quantity Range 1 ({max(quantity_range_1)})')
        plt.axvline(x=max(quantity_range_2), color='b', linestyle='--', label=f'Max Quantity Range 2 ({max(quantity_range_2)})')
        plt.xlabel("Order Quantity")
        plt.ylabel("Annual Total Cost")
        plt.title("Annual Total Cost vs. Order Quantity")
        plt.legend()
        plt.grid(True)
        plt.show()
        
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numeric values for S, D, H, and price tiers.")


# Create tkinter window
window = tk.Tk()
window.title("Quantity Discount")

# Create input labels and entry fields
label_s = tk.Label(window, text="Ordering Cost (S):")
label_s.grid(row=0, column=0)
entry_s = tk.Entry(window)
entry_s.grid(row=0, column=1)
entry_s.insert(tk.END, "49")
label_s = tk.Label(window, text="euros")
label_s.grid(row=0, column=2)


label_d = tk.Label(window, text="Annual Quantity Demanded (D):")
label_d.grid(row=1, column=0)
entry_d = tk.Entry(window)
entry_d.grid(row=1, column=1)
entry_d.insert(tk.END, "5000")
label_d = tk.Label(window, text="quantity/years")
label_d.grid(row=1, column=2)

label_h = tk.Label(window, text="Holding Cost per Unit (H):")
label_h.grid(row=2, column=0)
entry_h = tk.Entry(window)
entry_h.grid(row=2, column=1)
entry_h.insert(tk.END, "0.50")
label_h = tk.Label(window, text="euros")
label_h.grid(row=2, column=2)

label_i = tk.Label(window, text="Holding Cost as % of Unit Price (I):")
label_i.grid(row=3, column=0)
entry_i = tk.Entry(window)
entry_i.grid(row=3, column=1)
entry_i.insert(tk.END, "0.2")
#label_i = tk.Label(window, text="%")
#label_i.grid(row=3, column=2)

label_p = tk.Label(window, text="Unit Price (P):")
label_p.grid(row=4, column=0)
entry_p = tk.Entry(window)
entry_p.grid(row=4, column=1)
entry_p.insert(tk.END, "5")
label_p = tk.Label(window, text="euros")
label_p.grid(row=4, column=2)

label_lead_time = tk.Label(window, text="Lead Time (days):")
label_lead_time.grid(row=5, column=0)
entry_lead_time = tk.Entry(window)
entry_lead_time.grid(row=5, column=1)
entry_lead_time.insert(tk.END, "7")

label_price_tier_1 = tk.Label(window, text="Price Tier under 1000:")
label_price_tier_1.grid(row=6, column=0)
entry_price_tier_1 = tk.Entry(window)
entry_price_tier_1.grid(row=6, column=1)
entry_price_tier_1.insert(tk.END, "5")
label_price_tier_1 = tk.Label(window, text="euros")
label_price_tier_1.grid(row=6, column=2)

label_price_tier_2 = tk.Label(window, text="Price Tier between 1000 to 2000:")
label_price_tier_2.grid(row=7, column=0)
entry_price_tier_2 = tk.Entry(window)
entry_price_tier_2.grid(row=7, column=1)
entry_price_tier_2.insert(tk.END, "4.80")
label_price_tier_2 = tk.Label(window, text="euros")
label_price_tier_2.grid(row=7, column=2)

label_price_tier_3 = tk.Label(window, text="Price Tier above 2000:")
label_price_tier_3.grid(row=8, column=0)
entry_price_tier_3 = tk.Entry(window)
entry_price_tier_3.grid(row=8, column=1)
entry_price_tier_3.insert(tk.END, "4.75")
label_price_tier_3 = tk.Label(window, text="euros")
label_price_tier_3.grid(row=8, column=2)

# Create input labels and entry fields for quantity ranges
label_quantity_range_1 = tk.Label(window, text="Quantity Range 1-1000:")
label_quantity_range_1.grid(row=9, column=0)
entry_quantity_range_1 = tk.Entry(window)
entry_quantity_range_1.grid(row=9, column=1)
entry_quantity_range_1.insert(tk.END, "1000")
label_quantity_range_1 = tk.Label(window, text="quantity")
label_quantity_range_1.grid(row=9, column=2)

label_quantity_range_2 = tk.Label(window, text="Quantity Range 1000-2000:")
label_quantity_range_2.grid(row=10, column=0)
entry_quantity_range_2 = tk.Entry(window)
entry_quantity_range_2.grid(row=10, column=1)
entry_quantity_range_2.insert(tk.END, "1500")
label_quantity_range_2 = tk.Label(window, text="quantity")
label_quantity_range_2.grid(row=10, column=2)

label_quantity_range_3 = tk.Label(window, text="Quantity Range above 2000:")
label_quantity_range_3.grid(row=11, column=0)
entry_quantity_range_3 = tk.Entry(window)
entry_quantity_range_3.grid(row=11, column=1)
entry_quantity_range_3.insert(tk.END, "2500")
label_quantity_range_3 = tk.Label(window, text="quantity")
label_quantity_range_3.grid(row=11, column=2)


# Create calculate button
button_calculate = tk.Button(window, text=" Calculate ", command=calculate_eoq)
button_calculate.grid(row=12, column=0, columnspan=2)

# Run the tkinter event loop
window.mainloop()
