import tkinter as tk
from tkinter import messagebox
import subprocess

def open_new_window():
    # Fonction appelée lors du clic sur le bouton
    # pour ouvrir une nouvelle fenêtre
    new_window = tk.Toplevel(root)
    new_window.title("Welcome")

    # Création du titre dans la nouvelle fenêtre
    new_title_label = tk.Label(new_window, text="Welcome to your simulation environment", font=("Helvetica", 24))
    new_title_label.pack(pady=20)
    
    # Création du sous-titre
    title_label2 = tk.Label(new_window, text="The company starts the period with an initial inventory of 60 units\n There is a fixed cost associated with placing an order of $32 \n  Each individual items costs the company $3 to order \n The company incurs a holding cost of $1 per month for every item in inventory\n shortage cost of $3 per month for every item backlogged", font=("Helvetica", 15), bg="lightgray")
    title_label2.pack(pady=20)
    
    # Chargement de l'image
    image = tk.PhotoImage(file="inven2.png")

    # Affichage de l'image dans la nouvelle fenêtre
    image_label = tk.Label(new_window, image=image)
    image_label.pack()
    
    # Création du bouton pour la simulation EOQ
    button1 = tk.Button(new_window, text="Calculation of EOQ", command=run_EOQ)
    button1.pack(pady=10)
    
    # Création du bouton pour la simulation POQ
    button2 = tk.Button(new_window, text="Calculation of POQ", command=run_POQ)
    button2.pack(pady=10)
    
    # Création du bouton pour la simulation stochastique
    button3 = tk.Button(new_window, text=" Quantity Discounts", command=run_Quantity_discounts_model)
    button3.pack(pady=10)
    
    # Création du bouton pour la simulation stochastique
    button4 = tk.Button(new_window, text=" Single Period ", command=run_single_period_model)
    button4.pack(pady=10)

    # Création du bouton pour la simulation déterministe
    button5 = tk.Button(new_window, text=" Deterministic Demand", command=run_deterministic_demand)
    button5.pack(pady=10)

    # Création du bouton pour la simulation stochastique
    button6 = tk.Button(new_window, text=" Stochastic Demand", command=run_stochastic_demand)
    button6.pack(pady=10)
    

    # Mise à jour de la référence à l'image pour éviter sa suppression par le garbage collector
    image_label.image = image

def run_deterministic_demand():
    # Exécute le fichier deterministic_demand.py
    subprocess.run(["python", "deterministic_demand.py"])
    
def run_stochastic_demand():
    # Execute le fichier stochastic_demand
    subprocess.run(["python", "stochastic_demand_menu.py"])
    
def run_EOQ():
    # Execute le fichier stochastic_demand
    subprocess.run(["python", "Economic_order_quantity.py"]) 
    
def run_POQ():
    # Execute le fichier stochastic_demand
    subprocess.run(["python", "Production_order_quantity.py"]) 

def run_Quantity_discounts_model():
    # Execute le fichier stochastic_demand
    subprocess.run(["python", "Quantity_discounts_model.py"]) 

def run_single_period_model():
    # Execute le fichier single period
    subprocess.run(["python", "Single_period_moel.py"]) 

# Création de la fenêtre principale
root = tk.Tk()
root.title("Home")
root.geometry("400x300")
root.configure(bg="lightgray")

# Chargement de l'image inven1
image2 = tk.PhotoImage(file="inv.png")

# Création du titre
title_label = tk.Label(root, text="Inventory Management for Retail \n Deterministic Demand -- Stochastic Demand ", font=("Helvetica", 25), bg="lightgray")
title_label.grid(row=0, column=0, columnspan=2, pady=20, sticky="nsew")

# Création des champs de saisie pour le nom et le mot de passe
name_label = tk.Label(root, text="LOGIN:", font=("Helvetica", 20), bg="lightgray")
name_label.grid(row=1, column=0, pady=10, sticky="e")

name_entry = tk.Entry(root, font=("Helvetica", 20), bg="lightgray")
name_entry.grid(row=1, column=1, pady=5, sticky="w")

password_label = tk.Label(root, text="PASSWORD:", font=("Helvetica", 20), bg="lightgray")
password_label.grid(row=2, column=0, pady=10, sticky="e")

password_entry = tk.Entry(root, font=("Helvetica", 20), bg="lightgray", show="*")
password_entry.grid(row=2, column=1, pady=5, sticky="w")

# Création du bouton pour ouvrir une nouvelle fenêtre
button = tk.Button(root, text="     Enter       ", command=open_new_window, font=("Helvetica", 12))
button.grid(row=3, column=0, columnspan=3, pady=20, sticky="ns")

# Affichage de l'image 1 en bas de page
image_label1 = tk.Label(root, image=image2)
image_label1.grid(row=4, column=0, columnspan=2, pady=2, sticky="ns")

# Mise à jour de la référence à l'image pour éviter sa suppression par le garbage collector
image_label1.image = image2

# Configurer le placement en centre des cellules de la grille
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=1)
root.grid_rowconfigure(5, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)

#root.geometry("1266x700+0+0")
root.geometry("866x600+0+0")

# Boucle principale
root.mainloop()
